import pandas as pd

def clean_data(df):
    df['email'] = df['email'].str.lower().str.strip()
    df['phone'] = df['phone'].str.replace(r'\D', '', regex=True)
    df['website'] = df['website'].str.strip()
    df['name'] = df['name'].str.strip()
    df.drop_duplicates(subset=['name'], inplace=True)
    return df
