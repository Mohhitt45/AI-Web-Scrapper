import requests
from bs4 import BeautifulSoup
from logger import logger
import time

def scrape_page(url, retries=3, delay=2):
    for i in range(retries):
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'lxml')
            logger.info(f"Scraped {url} successfully")
            return soup
        except Exception as e:
            logger.warning(f"Error scraping {url}, attempt {i+1}: {e}")
            time.sleep(delay)
    logger.error(f"Failed to scrape {url} after {retries} attempts")
    return None
