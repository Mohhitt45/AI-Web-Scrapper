def extract_fields(soup):
    data = {}
    try:
        data['name'] = soup.find("h1").text.strip() if soup.find("h1") else None
        email_tag = soup.find("a", href=lambda x: x and "mailto:" in x)
        data['email'] = email_tag['href'].replace("mailto:", "").strip() if email_tag else None
        phone_tag = soup.find("a", href=lambda x: x and "tel:" in x)
        data['phone'] = phone_tag['href'].replace("tel:", "").strip() if phone_tag else None
        website_tag = soup.find("a", href=lambda x: x and "http" in x)
        data['website'] = website_tag['href'].strip() if website_tag else None
        data['address'] = soup.find("address").text.strip() if soup.find("address") else None
        data['description'] = soup.find("p").text.strip() if soup.find("p") else None
    except Exception as e:
        data['error'] = str(e)
    return data
