import pandas as pd
from scraper import scrape_page
from extractor import extract_fields
from cleaner import clean_data
from enrich import enrich_description
from logger import logger

# Load URLs
urls_df = pd.read_csv("input_urls.csv")
urls = urls_df['url'].tolist()

all_data = []
errors = 0

for url in urls:
    soup = scrape_page(url)
    if soup:
        data = extract_fields(soup)
        # Optional NLP enrichment
        data['entities'] = enrich_description(data.get('description', ''))
        all_data.append(data)
    else:
        errors += 1

# Convert to DataFrame
df = pd.DataFrame(all_data)

# Clean data
df = clean_data(df)

# Save output
df.to_csv("output.csv", index=False)

# Logging report
total = len(urls)
success = len(df)
incomplete = df.isnull().sum().sum()
logger.info(f"Total URLs: {total}")
logger.info(f"Successfully scraped: {success}")
logger.info(f"Errors: {errors}")
logger.info(f"Incomplete fields: {incomplete}")

print(f"Scraping complete. Output saved to output.csv")
