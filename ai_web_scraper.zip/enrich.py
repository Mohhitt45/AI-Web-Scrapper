import spacy

nlp = spacy.load("en_core_web_sm")

def enrich_description(text):
    if not text:
        return []
    doc = nlp(text)
    entities = [ent.text for ent in doc.ents]
    return entities
